import json, pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
M = json.load(open("run_meta.json")); BP = json.load(open("best_params.json"))
cvr = pd.read_csv("cv_results.csv"); res = pd.read_csv("final_test_results.csv"); tdf = pd.read_csv("tuning_trials.csv")
model, tech0, best = M["model"], M["tech0"], M["best"]
ss = getSampleStyleSheet(); B = ParagraphStyle("B", parent=ss["Normal"], fontSize=9.5, leading=14, spaceAfter=6)
W = A4[0] - 3.6*cm
def T(data, widths, font=8):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1F3A5F")),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),font),("GRID",(0,0),(-1,-1),.4,colors.grey),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#EEF2F7")])])); return t
doc = SimpleDocTemplate("Final_Results_Report.pdf", pagesize=A4, leftMargin=1.8*cm, rightMargin=1.8*cm, topMargin=1.8*cm, bottomMargin=1.8*cm)
st = [Paragraph("Final Results Report: Tuning, Final Models and Interpretation", ss["Title"]), Spacer(1,6)]
st += [Paragraph("1. Model selection from the 12 CV experiments", ss["Heading1"]),
       Paragraph(f"Sabse high PR-AUC <b>{model} + {tech0}</b> ka tha (5-fold CV PR-AUC {M['sel_pr']:.4f}). Isi ko tuning ke liye chuna gaya.", B)]
top = cvr.sort_values("pr_auc_mean", ascending=False).head(5)
rows = [["Rank","Model","Technique","PR-AUC","ROC-AUC","Recall"]] + [[i,r["model"],r["imbalance_technique"],f"{r['pr_auc_mean']:.4f}",f"{r['roc_auc_mean']:.4f}",f"{r['recall_mean']:.4f}"] for i,(_,r) in enumerate(top.iterrows(),1)]
st += [T(rows,[1.2*cm,4.5*cm,3.2*cm,2.8*cm,2.8*cm,2.8*cm]), Spacer(1,8)]
diff = BP["best_cv_pr_auc_3fold"] - M["sel_pr"]
st += [Paragraph("2. Hyperparameter tuning", ss["Heading1"]),
       Paragraph(f"{M['n_trials']} trials random search (Optuna is environment mein install nahi ho saka; 30-50 trials ki requirement poori hui). "
                 f"Objective: 3-fold CV PR-AUC on the training set. Best trial: <b>{BP['best_cv_pr_auc_3fold']:.4f}</b>; untuned default ka 5-fold CV PR-AUC {M['sel_pr']:.4f} tha "
                 f"(farak {diff:+.4f}, lekin folds alag hain, isliye seedha comparable nahi). <b>Practical matlab: tuning se koi saaf improvement nahi mila</b>; "
                 f"default parameters pehle se achhe the.", B)]
st += [T([["Parameter","Best value"]]+[[k,f"{v:.5g}" if isinstance(v,float) else str(v)] for k,v in best.items()],[6*cm,5*cm]), Spacer(1,6),
       Image("report_assets/tuning_history.png", W, W*3.2/6.5), PageBreak()]
st += [Paragraph("3. Final model and the four imbalance variants", ss["Heading1"]),
       Paragraph(f"Selected model poore training data ({M['n_tr']} rows) pe retrain hua (models/final_model.joblib). Phir wahi tuned parameters ke saath chaaron variants train hue aur "
                 f"hold-out test set ({M['n_te']} rows, {M['te_rate']:.1%} defaulters) pe evaluate hue. Threshold training out-of-fold predictions se F1 maximise karke chuna gaya (test leakage nahi).", B)]
rows = [["Variant","ROC-AUC","PR-AUC","F1","Recall","Precision","BalAcc","KS","Thr"]] + [[r["imbalance_technique"]]+[f"{r[k]:.4f}" for k in ["roc_auc","pr_auc","f1","recall","precision","balanced_acc","ks"]]+[f"{r['threshold']:.2f}"] for _,r in res.iterrows()]
st += [T(rows,[3*cm]+[(W-3*cm)/8]*8,7.5), Spacer(1,8), Image("report_assets/test_curves.png",W,W*3.8/9), Spacer(1,6), Image("report_assets/test_bars.png",W*.85,W*.85*3.4/7), PageBreak()]
bp, br, bf = (res.loc[res[k].idxmax()] for k in ["pr_auc","recall","f1"]); ref = res[res["imbalance_technique"]==tech0].iloc[0]
st += [Paragraph("4. Interpretation", ss["Heading1"]),
       Paragraph(f"<b>Ranking quality:</b> test PR-AUC sabse zyada <b>{bp['imbalance_technique']}</b> ka hai ({bp['pr_auc']:.4f}, ROC-AUC {bp['roc_auc']:.4f}). Selected config ({tech0}) ka test PR-AUC {ref['pr_auc']:.4f} hai jabki CV mein {M['sel_pr']:.4f} tha, yani generalisation gap chhota hai.", B),
       Paragraph(f"<b>Resampling ka asar:</b> is dataset mein SMOTE ({res.loc[res.imbalance_technique=='SMOTE','pr_auc'].iloc[0]:.4f}) aur undersampling ({res.loc[res.imbalance_technique=='undersampling','pr_auc'].iloc[0]:.4f}) ka test PR-AUC none/class_weight se kam hai. Gradient boosting ke liye class weighting kaafi hai; resampling ranking quality ghatati hai.", B),
       Paragraph(f"<b>Defaulter detection:</b> sabse high recall {br['imbalance_technique']} ({br['recall']:.4f}, precision {br['precision']:.4f}); best F1 {bf['imbalance_technique']} ({bf['f1']:.4f}). Recall aur precision ka trade-off business cost (missed default vs false alarm) se tay hona chahiye.", B),
       Paragraph("<b>Limitations:</b> ek hi train/test split; tuning sirf ek technique pe hui aur parameters baaki variants pe reuse hue; models sklearn ke HistGradientBoosting par hain (XGBoost/LightGBM yahan install nahi ho sake); SHAP/fairness analysis shamil nahi hai (Member 3).", B)]
doc.build(st)
tbl = "| Variant | ROC-AUC | PR-AUC | F1 | Recall | Precision | Threshold |\n|---|---|---|---|---|---|---|\n" + "".join(f"| {r['imbalance_technique']} | {r['roc_auc']:.4f} | {r['pr_auc']:.4f} | {r['f1']:.4f} | {r['recall']:.4f} | {r['precision']:.4f} | {r['threshold']:.2f} |\n" for _,r in res.iterrows())
open("HANDOVER_Member3.md","w").write(f"""# Handover to Member 3: Models and Methodology

## Files
- `models/final_model.joblib`: {model} + {tech0}, full train data pe fitted (preprocessing pipeline ke andar)
- `models/{model}_<technique>.joblib`: four variants (none, class_weight, SMOTE, undersampling)
- `models/thresholds.json`: har variant ka threshold (train OOF F1)
- `features.json`: input columns ka exact order; `data_split/train.csv`, `data_split/test.csv`
- `cv_results.csv`, `best_params.json`, `tuning_trials.csv`, `final_test_results.csv`
- `Detailed_Modeling_Report.pdf`, `Final_Results_Report.pdf`

## Methodology
1. Data: uploaded CSV (SeriousDlqin2yrs target, {M['te_rate']:.1%} defaulters). Codes >=90 in past-due columns missing mane gaye; utilization clip 10; age clip 18-100; median imputation (train folds ke andar); TOTAL_PAST_DUE, INCOME_MISSING features.
2. Split 80/20 stratified (seed 42); test sirf final evaluation ke liye.
3. 12 experiments: 3 models x 4 imbalance techniques, 5-fold CV; SMOTE/undersampling sirf training folds mein.
4. Selection: best CV PR-AUC -> {model} + {tech0}. Tuning: {M['n_trials']}-trial random search.
5. Best params: `{json.dumps(best)}`

## Final test results
{tbl}
## Member 3 ke liye
- SHAP: `shap.TreeExplainer(pipe.named_steps["clf"])` ko `pipe.named_steps["pre"].transform(X)` ke output pe chalao (HistGradientBoosting ke liye shap version check karo; slow ho to KernelExplainer/sample use karo).
- Resampled variants ki probabilities miscalibrated ho sakti hain; calibration check karo.
- Note: libraries sklearn-based hain; paper mein XGBoost/LightGBM chahiye to `run_all.py` apne laptop pe chalao.
""")
