"""
sklearn-only pipeline (Tasks 1-9) for the uploaded 'Give Me Some Credit' style CSV.
Stand-ins used because xgboost/lightgbm/imblearn/optuna are not installable here:
  XGBoost/LightGBM -> HistGradientBoosting (LightGBM-style), RandomForest
  imblearn SMOTE / RandomUnderSampler -> own implementation (fold-internal, no leakage)
  Optuna -> random search (30 trials)
"""
import json, os, sys, time, warnings
import numpy as np, pandas as pd, joblib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import QuantileTransformer
from sklearn.pipeline import Pipeline
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import (roc_auc_score, average_precision_score, f1_score, recall_score, precision_score,
                             balanced_accuracy_score, brier_score_loss, roc_curve, precision_recall_curve)
warnings.filterwarnings("ignore")
SEED, TARGET = 42, "SeriousDlqin2yrs"
TECHS = ["none", "class_weight", "SMOTE", "undersampling"]
MODELS = ["LogisticRegression", "RandomForest", "HistGradientBoosting"]
N_TRIALS = int(os.environ.get("N_TRIALS", 30))
t_start = time.time()


def log(*a):
    print(f"[{time.time()-t_start:6.0f}s]", *a, flush=True)


# ------------------------------------------------------------------ data
def load(path):
    df = pd.read_csv(path)
    df = df.drop(columns=[c for c in df.columns if c.startswith("Unnamed")]).drop_duplicates()
    late = [c for c in df.columns if c.startswith("NumberOfTime")]
    for c in late:
        df.loc[df[c] >= 90, c] = np.nan                 # 96/98 = special codes -> missing
    df["RevolvingUtilizationOfUnsecuredLines"] = df["RevolvingUtilizationOfUnsecuredLines"].clip(upper=10)
    df["age"] = df["age"].clip(18, 100)
    df["TOTAL_PAST_DUE"] = df[late].fillna(0).sum(axis=1)
    df["INCOME_MISSING"] = df["MonthlyIncome"].isna().astype(int)
    return df


# --------------------------------------------------- model / resampling
def make_pre(model):
    steps = [("imp", SimpleImputer(strategy="median"))]
    if model == "LogisticRegression":
        steps.append(("q", QuantileTransformer(n_quantiles=200, output_distribution="normal", random_state=SEED)))
    return Pipeline(steps)


def make_clf(model, tech, params):
    cw = tech == "class_weight"
    if model == "LogisticRegression":
        d = dict(C=1.0, max_iter=3000); d.update(params)
        return LogisticRegression(class_weight="balanced" if cw else None, **d)
    if model == "RandomForest":
        d = dict(n_estimators=150, min_samples_leaf=5, max_depth=12); d.update(params)
        return RandomForestClassifier(class_weight="balanced_subsample" if cw else None,
                                      random_state=SEED, n_jobs=-1, **d)
    d = dict(max_iter=250, learning_rate=0.05, max_depth=4); d.update(params)
    return HistGradientBoostingClassifier(class_weight="balanced" if cw else None, random_state=SEED, **d)


def smote(X, y, rng, k=5):
    Xm = X[y == 1]; n_new = int((y == 0).sum() - (y == 1).sum())
    idx = NearestNeighbors(n_neighbors=k + 1).fit(Xm).kneighbors(Xm, return_distance=False)[:, 1:]
    b = rng.randint(0, len(Xm), n_new); nb = idx[b, rng.randint(0, k, n_new)]
    Xn = Xm[b] + rng.rand(n_new, 1) * (Xm[nb] - Xm[b])
    return np.vstack([X, Xn]), np.concatenate([y, np.ones(n_new, dtype=y.dtype)])


def undersample(X, y, rng):
    i1, i0 = np.where(y == 1)[0], np.where(y == 0)[0]
    keep = np.concatenate([i1, rng.choice(i0, len(i1), replace=False)])
    return X[keep], y[keep]


def fit_pipe(model, tech, params, X, y):
    rng = np.random.RandomState(SEED)
    pre = make_pre(model); Xt = pre.fit_transform(X); yt = np.asarray(y)
    if tech == "SMOTE":
        Xt, yt = smote(Xt, yt, rng)
    elif tech == "undersampling":
        Xt, yt = undersample(Xt, yt, rng)
    clf = make_clf(model, tech, params).fit(Xt, yt)
    return Pipeline([("pre", pre), ("clf", clf)])


def metrics(y, p, thr=0.5):
    pred = (p >= thr).astype(int); fpr, tpr, _ = roc_curve(y, p)
    return {"roc_auc": roc_auc_score(y, p), "pr_auc": average_precision_score(y, p), "f1": f1_score(y, pred),
            "recall": recall_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
            "balanced_acc": balanced_accuracy_score(y, pred), "ks": float((tpr - fpr).max()),
            "brier": brier_score_loss(y, p), "threshold": thr}


def cv_scores(model, tech, params, X, y, n=5, oof=False):
    skf = StratifiedKFold(n, shuffle=True, random_state=SEED)
    rows, o = [], np.zeros(len(y))
    for tr, va in skf.split(X, y):
        pipe = fit_pipe(model, tech, params, X.iloc[tr], y.iloc[tr])
        p = pipe.predict_proba(X.iloc[va])[:, 1]; o[va] = p
        rows.append(metrics(y.iloc[va], p))
    return (pd.DataFrame(rows), o) if oof else pd.DataFrame(rows)


def best_thr(y, p):
    ts = np.linspace(0.02, 0.95, 94)
    return float(ts[np.argmax([f1_score(y, p >= t) for t in ts])])


# ------------------------------------------------------------------ main
def main(path):
    os.makedirs("models", exist_ok=True); os.makedirs("data_split", exist_ok=True); os.makedirs("report_assets", exist_ok=True)
    df = load(path)
    X, y = df.drop(columns=TARGET), df[TARGET]
    log(f"data {df.shape}, default rate {y.mean():.4f}")
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
    Xtr.assign(TARGET=ytr).to_csv("data_split/train.csv", index=False)
    Xte.assign(TARGET=yte).to_csv("data_split/test.csv", index=False)
    json.dump(list(X.columns), open("features.json", "w"), indent=2)

    # ---- Task 1: 12 experiments
    rows, n = [], 0
    for m in MODELS:
        for t in TECHS:
            n += 1; t0 = time.time()
            s = cv_scores(m, t, {}, Xtr, ytr)
            r = {"exp_id": n, "model": m, "imbalance_technique": t}
            for k in ["roc_auc", "pr_auc", "f1", "recall", "precision", "balanced_acc"]:
                r[k + "_mean"], r[k + "_std"] = s[k].mean(), s[k].std()
            r["time_sec"] = time.time() - t0; rows.append(r)
            log(f"[{n:2d}/12] {m:21s}+{t:13s} AUC={r['roc_auc_mean']:.4f} PR={r['pr_auc_mean']:.4f} "
                f"F1={r['f1_mean']:.4f} Rec={r['recall_mean']:.4f}")
    cvr = pd.DataFrame(rows).round(4); cvr.to_csv("cv_results.csv", index=False)
    sel = cvr.loc[cvr["pr_auc_mean"].idxmax()]; model, tech0 = sel["model"], sel["imbalance_technique"]
    log(f"SELECTED: {model} + {tech0}")

    # ---- Task 4: tuning (random search, 3-fold, PR-AUC)
    rng = np.random.RandomState(SEED); trials = []; raws = []
    def sample():
        if model == "LogisticRegression":
            return {"C": float(10 ** rng.uniform(-3, 2))}
        if model == "RandomForest":
            return {"n_estimators": int(rng.choice([150, 250, 400])), "max_depth": rng.choice([6, 8, 12, 16, 0]),
                    "min_samples_leaf": int(rng.choice([1, 3, 5, 10, 20])),
                    "max_features": rng.choice(["sqrt", "0.3", "0.5"])}
        return {"learning_rate": float(10 ** rng.uniform(-2, -0.7)), "max_depth": int(rng.choice([3, 4, 5, 6, 8])),
                "max_leaf_nodes": int(rng.choice([15, 31, 63])), "min_samples_leaf": int(rng.choice([20, 50, 100])),
                "l2_regularization": float(10 ** rng.uniform(-3, 1)), "max_iter": int(rng.choice([150, 250, 400]))}
    def clean(p):
        p = dict(p)
        if p.get("max_depth") == 0: p["max_depth"] = None
        if p.get("max_depth") is not None and model != "LogisticRegression": p["max_depth"] = int(p["max_depth"])
        if p.get("max_features") in ("0.3", "0.5"): p["max_features"] = float(p["max_features"])
        return p
    for i in range(N_TRIALS):
        p = sample(); raws.append(p); v = cv_scores(model, tech0, clean(p), Xtr, ytr, n=3)["pr_auc"].mean()
        trials.append({"trial": i, "value": v, **{k: str(x) for k, x in p.items()}})
        log(f"trial {i+1}/{N_TRIALS} PR-AUC={v:.4f}")
    tdf = pd.DataFrame(trials); tdf.to_csv("tuning_trials.csv", index=False)
    bi = int(tdf["value"].idxmax()); best = clean(raws[bi]); best_val = float(tdf["value"].max())
    json.dump({"model": model, "tuned_on_technique": tech0, "n_trials": N_TRIALS, "method": "random search",
               "best_cv_pr_auc_3fold": best_val, "best_params": best}, open("best_params.json", "w"), indent=2, default=str)
    plt.figure(figsize=(6.5, 3.2)); plt.plot(tdf["trial"], tdf["value"], "o", alpha=.5)
    plt.plot(tdf["trial"], tdf["value"].cummax(), "r-"); plt.xlabel("Trial"); plt.ylabel("CV PR-AUC (3-fold)")
    plt.title("Random-search tuning history"); plt.tight_layout(); plt.savefig("report_assets/tuning_history.png", dpi=200); plt.close()
    log("best params", best, round(best_val, 4))

    # ---- Task 5: retrain selected on full train
    joblib.dump(fit_pipe(model, tech0, best, Xtr, ytr), "models/final_model.joblib")

    # ---- Tasks 6-7: four variants
    res, curves, thr = [], {}, {}
    for t in TECHS:
        _, oof = cv_scores(model, t, best, Xtr, ytr, oof=True)
        thr[t] = best_thr(ytr, oof)
        pipe = fit_pipe(model, t, best, Xtr, ytr)
        joblib.dump(pipe, f"models/{model}_{t}.joblib")
        p = pipe.predict_proba(Xte)[:, 1]; curves[t] = p
        res.append({"model": model, "imbalance_technique": t, **metrics(yte, p, thr[t])})
        log(f"variant {t}: test PR={res[-1]['pr_auc']:.4f} AUC={res[-1]['roc_auc']:.4f} Rec={res[-1]['recall']:.4f}")
    json.dump(thr, open("models/thresholds.json", "w"), indent=2)
    rdf = pd.DataFrame(res); rdf.round(4).to_csv("final_test_results.csv", index=False)

    fig, ax = plt.subplots(1, 2, figsize=(9, 3.8))
    for t, p in curves.items():
        f, tp, _ = roc_curve(yte, p); ax[0].plot(f, tp, label=t)
        pr, rc, _ = precision_recall_curve(yte, p); ax[1].plot(rc, pr, label=t)
    ax[0].plot([0, 1], [0, 1], "k--"); ax[0].set_title("ROC (test)"); ax[0].set_xlabel("FPR"); ax[0].set_ylabel("TPR")
    ax[1].set_title("Precision-Recall (test)"); ax[1].set_xlabel("Recall"); ax[1].set_ylabel("Precision"); ax[0].legend(fontsize=7)
    plt.tight_layout(); plt.savefig("report_assets/test_curves.png", dpi=200); plt.close()
    rdf.set_index("imbalance_technique")[["roc_auc", "pr_auc", "f1", "recall", "precision"]].plot(
        kind="bar", figsize=(7, 3.4), rot=0, title="Test metrics by imbalance variant")
    plt.tight_layout(); plt.savefig("report_assets/test_bars.png", dpi=200); plt.close()

    json.dump({"model": model, "tech0": tech0, "best": best, "best_val": best_val, "sel_pr": float(sel["pr_auc_mean"]),
               "n_tr": len(Xtr), "n_te": len(Xte), "te_rate": float(yte.mean()), "n_trials": N_TRIALS},
              open("run_meta.json", "w"), indent=2, default=str)
    log("DONE")


if __name__ == "__main__":
    main(sys.argv[1])
